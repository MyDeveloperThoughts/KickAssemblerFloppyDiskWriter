MultiDisk Writer plugin for Kick Assembler
------------------------------------------
A Disk Writer plugin for Kick Assembler that supports the 1541, 1571 and 1581 disk formats. d64, d71 and 81.
Written by Chris Zinn

 Get the latest version here: https://github.com/MyDeveloperThoughts/KickAssemblerFloppyDiskWriter/blob/main/multiDiskPlugin.zip
    Click on the Download raw file button
    Unzip the contents of the multiDiskPlugin.zip file into the plugins folder of KickAssembler.

 Documentation Here         : https://github.com/MyDeveloperThoughts/KickAssemblerFloppyDiskWriter/blob/main/README.md
 GitHub Repo                : https://github.com/MyDeveloperThoughts/KickAssemblerFloppyDiskWriter
