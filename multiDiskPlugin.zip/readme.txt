MultiDisk Writer plugin for Kick Assembler
------------------------------------------
A Disk Writer plugin for Kick Assembler that supports the 1541, 1571 and 1581 disk formats. d64, d71 and 81.
Written by Chris Zinn



GITHUB Repo: https://github.com/MyDeveloperThoughts/KickAssemblerFloppyDiskWriter
